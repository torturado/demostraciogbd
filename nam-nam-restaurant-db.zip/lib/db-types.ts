// Type definitions for database operations

export interface CategoriaFormData {
  nom: string
  descripcio?: string
}

export interface ProducteFormData {
  nom: string
  descripcio?: string
  preu: number
  disponible: boolean
  categoria_id: number
}

export interface ClientFormData {
  nom: string
  cognom: string
  email: string
  telefon?: string
}

export interface ReservaFormData {
  client_id: number
  data_reserva: string
  num_persones: number
  estat: string
  notes?: string
}

export interface ComandaFormData {
  client_id: number
  detalls: {
    producte_id: number
    quantitat: number
  }[]
}

export interface QueryResult {
  columns: string[]
  rows: any[]
  title: string
}
