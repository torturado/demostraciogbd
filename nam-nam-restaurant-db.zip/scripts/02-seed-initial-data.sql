-- Seed initial data for demo purposes

-- Insert sample categories
INSERT INTO categories (nom, descripcio) VALUES
('Entrants', 'Plats per començar el menjar'),
('Plats principals', 'Plats forts del restaurant'),
('Postres', 'Dolços i postres casolanes'),
('Begudes', 'Refrescos, vins i altres begudes');

-- Insert sample products
INSERT INTO productes (nom, descripcio, preu, disponible, categoria_id) VALUES
('Amanida Cèsar', 'Amanida fresca amb pollastre i parmesà', 8.50, TRUE, 1),
('Croquetes de pernil', 'Croquetes casolanes de pernil ibèric', 7.00, TRUE, 1),
('Paella valenciana', 'Paella tradicional amb marisc i pollastre', 15.50, TRUE, 2),
('Entrecot a la brasa', 'Entrecot de vedella amb patates', 18.00, TRUE, 2),
('Tiramisú', 'Postres italiana amb cafè i mascarpone', 5.50, TRUE, 3),
('Crema catalana', 'Postres tradicional catalana', 4.50, TRUE, 3),
('Vi negre Rioja', 'Ampolla de vi negre D.O. Rioja', 12.00, TRUE, 4),
('Aigua mineral', 'Ampolla d''aigua mineral 1L', 2.00, TRUE, 4);

-- Insert sample clients
INSERT INTO clients (nom, cognom, email, telefon) VALUES
('Joan', 'García', 'joan.garcia@example.com', '612345678'),
('Maria', 'Martínez', 'maria.martinez@example.com', '623456789'),
('Pere', 'López', 'pere.lopez@example.com', '634567890');
