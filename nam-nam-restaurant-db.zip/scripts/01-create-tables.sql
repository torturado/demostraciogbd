-- Script to create all tables for Ñam Ñam Restaurant Database
-- This script will be executed automatically by the demo

CREATE TABLE IF NOT EXISTS categories (
  id INT AUTO_INCREMENT PRIMARY KEY,
  nom VARCHAR(100) NOT NULL,
  descripcio TEXT,
  creat_a TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS productes (
  id INT AUTO_INCREMENT PRIMARY KEY,
  nom VARCHAR(150) NOT NULL,
  descripcio TEXT,
  preu DECIMAL(10, 2) NOT NULL,
  disponible BOOLEAN DEFAULT TRUE,
  categoria_id INT NOT NULL,
  creat_a TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (categoria_id) REFERENCES categories(id) ON DELETE CASCADE,
  INDEX idx_categoria (categoria_id)
);

CREATE TABLE IF NOT EXISTS clients (
  id INT AUTO_INCREMENT PRIMARY KEY,
  nom VARCHAR(100) NOT NULL,
  cognom VARCHAR(100) NOT NULL,
  email VARCHAR(150) UNIQUE NOT NULL,
  telefon VARCHAR(20),
  creat_a TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS reserves (
  id INT AUTO_INCREMENT PRIMARY KEY,
  client_id INT NOT NULL,
  data_reserva DATETIME NOT NULL,
  num_persones INT NOT NULL,
  estat VARCHAR(50) DEFAULT 'pendent',
  notes TEXT,
  creat_a TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (client_id) REFERENCES clients(id) ON DELETE CASCADE,
  INDEX idx_client (client_id)
);

CREATE TABLE IF NOT EXISTS comandes (
  id INT AUTO_INCREMENT PRIMARY KEY,
  client_id INT NOT NULL,
  data_comanda TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  total DECIMAL(10, 2) NOT NULL,
  estat VARCHAR(50) DEFAULT 'pendent',
  FOREIGN KEY (client_id) REFERENCES clients(id) ON DELETE CASCADE,
  INDEX idx_client (client_id)
);

CREATE TABLE IF NOT EXISTS detalls_comanda (
  id INT AUTO_INCREMENT PRIMARY KEY,
  comanda_id INT NOT NULL,
  producte_id INT NOT NULL,
  quantitat INT NOT NULL,
  preu_unitat DECIMAL(10, 2) NOT NULL,
  subtotal DECIMAL(10, 2) NOT NULL,
  FOREIGN KEY (comanda_id) REFERENCES comandes(id) ON DELETE CASCADE,
  FOREIGN KEY (producte_id) REFERENCES productes(id) ON DELETE CASCADE,
  INDEX idx_comanda (comanda_id),
  INDEX idx_producte (producte_id)
);
