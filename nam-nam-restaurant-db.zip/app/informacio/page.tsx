import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Database, Table, LinkIcon, FileCode, Search, ExternalLink } from "lucide-react"
import Link from "next/link"

export default function InformacioPage() {
  return (
    <div className="container py-12">
      <div className="max-w-4xl mx-auto">
        <div className="mb-8">
          <h1 className="text-3xl font-bold mb-2">Informació del sistema</h1>
          <p className="text-muted-foreground text-balance">
            Documentació completa del model de dades, arquitectura i funcionalitats de la base de dades del Restaurant
            Ñam Ñam.
          </p>
        </div>

        <div className="space-y-6">
          {/* Overview */}
          <Card>
            <CardHeader>
              <div className="flex items-center gap-2 mb-2">
                <Database className="h-5 w-5 text-primary" />
                <CardTitle>Objectiu del projecte</CardTitle>
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              <p className="text-muted-foreground leading-relaxed">
                Aquest projecte és una demo acadèmica que demostra el cicle complet de gestió de dades en una aplicació
                web moderna. Simula el sistema de gestió d'un restaurant, incloent categories de productes, inventari,
                clients, reserves i comandes.
              </p>
              <div className="flex flex-wrap gap-2">
                <Badge variant="outline">Demo educativa</Badge>
                <Badge variant="outline">Base de dades relacional</Badge>
                <Badge variant="outline">CRUD complet</Badge>
                <Badge variant="outline">Consultes SQL</Badge>
              </div>
            </CardContent>
          </Card>

          {/* Entities */}
          <Card>
            <CardHeader>
              <div className="flex items-center gap-2 mb-2">
                <Table className="h-5 w-5 text-primary" />
                <CardTitle>Entitats del sistema</CardTitle>
              </div>
              <CardDescription>Taules principals de la base de dades MySQL</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="border-l-2 border-primary pl-4">
                  <h4 className="font-semibold mb-1">Categories</h4>
                  <p className="text-sm text-muted-foreground">
                    Organitza els productes en grups (entrants, plats principals, postres, begudes). Cada categoria pot
                    tenir múltiples productes.
                  </p>
                </div>

                <div className="border-l-2 border-chart-2 pl-4">
                  <h4 className="font-semibold mb-1">Productes</h4>
                  <p className="text-sm text-muted-foreground">
                    Articles del menú amb nom, descripció, preu i disponibilitat. Cada producte pertany a una categoria
                    (relació N:1).
                  </p>
                </div>

                <div className="border-l-2 border-chart-3 pl-4">
                  <h4 className="font-semibold mb-1">Clients</h4>
                  <p className="text-sm text-muted-foreground">
                    Usuaris registrats amb dades de contacte. Poden fer reserves i comandes. L'email és únic per
                    garantir la integritat.
                  </p>
                </div>

                <div className="border-l-2 border-chart-4 pl-4">
                  <h4 className="font-semibold mb-1">Reserves</h4>
                  <p className="text-sm text-muted-foreground">
                    Reserves de taula associades a un client, amb data, número de persones i estat (pendent, confirmada,
                    cancel·lada).
                  </p>
                </div>

                <div className="border-l-2 border-chart-5 pl-4">
                  <h4 className="font-semibold mb-1">Comandes</h4>
                  <p className="text-sm text-muted-foreground">
                    Comandes realitzades per clients amb total calculat i estat. Cada comanda té múltiples línies de
                    detall.
                  </p>
                </div>

                <div className="border-l-2 border-border pl-4">
                  <h4 className="font-semibold mb-1">Detalls de comanda</h4>
                  <p className="text-sm text-muted-foreground">
                    Línies individuals de cada comanda amb producte, quantitat, preu unitari i subtotal. Taula
                    intermèdia entre comandes i productes.
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Relationships */}
          <Card>
            <CardHeader>
              <div className="flex items-center gap-2 mb-2">
                <LinkIcon className="h-5 w-5 text-primary" />
                <CardTitle>Relacions entre entitats</CardTitle>
              </div>
              <CardDescription>Claus foranes i integritat referencial</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                <div className="flex items-start gap-3 p-3 rounded-lg bg-secondary/50">
                  <div className="text-xs font-mono bg-background px-2 py-1 rounded">1:N</div>
                  <div className="flex-1">
                    <p className="text-sm">
                      <span className="font-semibold">Categoria → Productes:</span> Una categoria pot tenir múltiples
                      productes
                    </p>
                  </div>
                </div>

                <div className="flex items-start gap-3 p-3 rounded-lg bg-secondary/50">
                  <div className="text-xs font-mono bg-background px-2 py-1 rounded">1:N</div>
                  <div className="flex-1">
                    <p className="text-sm">
                      <span className="font-semibold">Client → Reserves:</span> Un client pot fer múltiples reserves
                    </p>
                  </div>
                </div>

                <div className="flex items-start gap-3 p-3 rounded-lg bg-secondary/50">
                  <div className="text-xs font-mono bg-background px-2 py-1 rounded">1:N</div>
                  <div className="flex-1">
                    <p className="text-sm">
                      <span className="font-semibold">Client → Comandes:</span> Un client pot fer múltiples comandes
                    </p>
                  </div>
                </div>

                <div className="flex items-start gap-3 p-3 rounded-lg bg-secondary/50">
                  <div className="text-xs font-mono bg-background px-2 py-1 rounded">1:N</div>
                  <div className="flex-1">
                    <p className="text-sm">
                      <span className="font-semibold">Comanda → Detalls:</span> Una comanda conté múltiples línies de
                      detall
                    </p>
                  </div>
                </div>

                <div className="flex items-start gap-3 p-3 rounded-lg bg-secondary/50">
                  <div className="text-xs font-mono bg-background px-2 py-1 rounded">N:M</div>
                  <div className="flex-1">
                    <p className="text-sm">
                      <span className="font-semibold">Comandes ↔ Productes:</span> Relació molts a molts a través de la
                      taula detalls_comanda
                    </p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Operations */}
          <Card>
            <CardHeader>
              <div className="flex items-center gap-2 mb-2">
                <FileCode className="h-5 w-5 text-primary" />
                <CardTitle>Operacions implementades</CardTitle>
              </div>
              <CardDescription>Funcionalitats CRUD i consultes</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div>
                  <h4 className="font-semibold mb-2 flex items-center gap-2">
                    <Badge>CREATE</Badge> Inserció de dades
                  </h4>
                  <p className="text-sm text-muted-foreground mb-2">
                    Formularis amb validació per crear categories, productes, clients, reserves i comandes. Inclou
                    validació d'emails únics i càlcul automàtic de totals.
                  </p>
                </div>

                <div>
                  <h4 className="font-semibold mb-2 flex items-center gap-2">
                    <Badge>READ</Badge> Lectura i visualització
                  </h4>
                  <p className="text-sm text-muted-foreground mb-2">
                    Dashboard amb totes les taules carregades en temps real des de MySQL. Utilitza Prisma ORM per
                    obtenir dades amb relacions incloses.
                  </p>
                </div>

                <div>
                  <h4 className="font-semibold mb-2 flex items-center gap-2">
                    <Badge>QUERY</Badge> Consultes SQL avançades
                  </h4>
                  <p className="text-sm text-muted-foreground mb-2">
                    8 consultes predefinides que demostren INNER JOIN, LEFT JOIN, GROUP BY, agregacions (COUNT, SUM),
                    filtres WHERE i ordenació ORDER BY.
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Queries */}
          <Card>
            <CardHeader>
              <div className="flex items-center gap-2 mb-2">
                <Search className="h-5 w-5 text-primary" />
                <CardTitle>Consultes SQL disponibles</CardTitle>
              </div>
              <CardDescription>Exemples de tècniques de consulta</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-2 text-sm">
                <div className="flex items-start gap-2">
                  <span className="text-primary">•</span>
                  <span className="text-muted-foreground">Productes amb categories (INNER JOIN)</span>
                </div>
                <div className="flex items-start gap-2">
                  <span className="text-primary">•</span>
                  <span className="text-muted-foreground">Clients amb total de comandes (LEFT JOIN + GROUP BY)</span>
                </div>
                <div className="flex items-start gap-2">
                  <span className="text-primary">•</span>
                  <span className="text-muted-foreground">Top 10 productes més venuts (agregacions)</span>
                </div>
                <div className="flex items-start gap-2">
                  <span className="text-primary">•</span>
                  <span className="text-muted-foreground">Reserves agrupades per estat (GROUP BY)</span>
                </div>
                <div className="flex items-start gap-2">
                  <span className="text-primary">•</span>
                  <span className="text-muted-foreground">Ingressos diaris (DATE + GROUP BY)</span>
                </div>
                <div className="flex items-start gap-2">
                  <span className="text-primary">•</span>
                  <span className="text-muted-foreground">Ingressos per categoria (múltiples JOINs)</span>
                </div>
                <div className="flex items-start gap-2">
                  <span className="text-primary">•</span>
                  <span className="text-muted-foreground">Clients sense comandes (LEFT JOIN + WHERE NULL)</span>
                </div>
                <div className="flex items-start gap-2">
                  <span className="text-primary">•</span>
                  <span className="text-muted-foreground">Comandes superiors a 50€ (WHERE + ORDER BY)</span>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Tech Stack */}
          <Card>
            <CardHeader>
              <CardTitle>Stack tecnològic</CardTitle>
              <CardDescription>Tecnologies utilitzades en el projecte</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid md:grid-cols-2 gap-4">
                <div>
                  <h4 className="font-semibold mb-2 text-sm">Frontend</h4>
                  <div className="space-y-1 text-sm text-muted-foreground">
                    <p>• Next.js 15 (App Router)</p>
                    <p>• React 19</p>
                    <p>• TypeScript</p>
                    <p>• Tailwind CSS v4</p>
                    <p>• shadcn/ui components</p>
                  </div>
                </div>
                <div>
                  <h4 className="font-semibold mb-2 text-sm">Backend</h4>
                  <div className="space-y-1 text-sm text-muted-foreground">
                    <p>• MySQL database</p>
                    <p>• Prisma ORM</p>
                    <p>• Next.js API Routes</p>
                    <p>• Server Components</p>
                    <p>• React Hook Form</p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Conclusions */}
          <Card>
            <CardHeader>
              <CardTitle>Conclusions</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <p className="text-muted-foreground leading-relaxed">
                Aquest projecte demostra com implementar un sistema complet de gestió de dades amb una base de dades
                relacional. Cobreix des del disseny del model de dades fins a la implementació de formularis interactius
                i consultes SQL complexes.
              </p>
              <p className="text-muted-foreground leading-relaxed">
                L'ús de Prisma ORM facilita la interacció amb MySQL mantenint la seguretat (prevenció d'injeccions SQL)
                i la tipificació estàtica amb TypeScript. Les consultes raw SQL permeten demostrar tècniques avançades
                quan és necessari.
              </p>
            </CardContent>
          </Card>

          {/* External Links */}
          <Card>
            <CardHeader>
              <CardTitle>Referències externes</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                <Link
                  href="https://www.prisma.io/docs"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center gap-2 text-sm text-primary hover:underline"
                >
                  <ExternalLink className="h-4 w-4" />
                  Documentació de Prisma ORM
                </Link>
                <Link
                  href="https://nextjs.org/docs"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center gap-2 text-sm text-primary hover:underline"
                >
                  <ExternalLink className="h-4 w-4" />
                  Documentació de Next.js
                </Link>
                <Link
                  href="https://dev.mysql.com/doc/"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center gap-2 text-sm text-primary hover:underline"
                >
                  <ExternalLink className="h-4 w-4" />
                  Documentació de MySQL
                </Link>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
