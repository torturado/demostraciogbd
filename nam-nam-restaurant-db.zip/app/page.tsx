import Link from "next/link"
import { Card, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Database, FileText, Search, Table, PlusCircle, ArrowRight } from "lucide-react"

const features = [
  {
    title: "Inserir dades",
    description:
      "Formularis interactius per afegir categories, productes, clients, reserves i comandes a la base de dades.",
    icon: PlusCircle,
    href: "/inserir-dades",
    color: "text-chart-1",
  },
  {
    title: "Consultes SQL",
    description: "Executa consultes SQL predefinides amb joins, agregacions i filtres per explorar les dades.",
    icon: Search,
    href: "/consultes",
    color: "text-chart-2",
  },
  {
    title: "Informació del sistema",
    description: "Documentació completa del model de dades, entitats, relacions i arquitectura del projecte.",
    icon: FileText,
    href: "/informacio",
    color: "text-chart-3",
  },
  {
    title: "Visualitzar dades",
    description: "Dashboard amb taules que mostren totes les dades emmagatzemades a la base de dades en temps real.",
    icon: Table,
    href: "/visualitzar-dades",
    color: "text-chart-4",
  },
]

export default function HomePage() {
  return (
    <div className="container py-12 md:py-20">
      {/* Hero Section */}
      <section className="max-w-4xl mx-auto text-center mb-16 md:mb-24">
        <div className="inline-flex items-center justify-center p-2 mb-6 rounded-lg bg-primary/10 border border-primary/20">
          <Database className="h-8 w-8 text-primary" />
        </div>

        <h1 className="text-4xl md:text-6xl font-bold mb-6 text-balance leading-tight">
          Base de dades
          <br />
          <span className="text-primary">Restaurant Ñam Ñam</span>
        </h1>

        <p className="text-lg md:text-xl text-muted-foreground mb-8 text-balance max-w-2xl mx-auto leading-relaxed">
          Demo acadèmica que recorre el cicle complet de dades: des de la documentació del model fins a la inserció de
          registres i consultes visuals amb MySQL i Prisma.
        </p>

        <div className="flex flex-col sm:flex-row gap-4 justify-center">
          <Button asChild size="lg" className="gap-2">
            <Link href="/inserir-dades">
              Començar demo
              <ArrowRight className="h-4 w-4" />
            </Link>
          </Button>
          <Button asChild size="lg" variant="outline" className="gap-2 bg-transparent">
            <Link href="/informacio">
              Veure documentació
              <FileText className="h-4 w-4" />
            </Link>
          </Button>
        </div>
      </section>

      {/* Features Grid */}
      <section className="max-w-6xl mx-auto">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold mb-4 text-balance">Explora el sistema</h2>
          <p className="text-muted-foreground text-balance max-w-2xl mx-auto">
            Quatre seccions principals per entendre com funciona una base de dades relacional en un context real.
          </p>
        </div>

        <div className="grid md:grid-cols-2 gap-6">
          {features.map((feature) => {
            const Icon = feature.icon
            return (
              <Link key={feature.href} href={feature.href} className="group">
                <Card className="h-full transition-all hover:border-primary/50 hover:shadow-lg hover:shadow-primary/5">
                  <CardHeader>
                    <div className="flex items-start justify-between mb-2">
                      <div className={`p-2 rounded-lg bg-card border border-border ${feature.color}`}>
                        <Icon className="h-6 w-6" />
                      </div>
                      <ArrowRight className="h-5 w-5 text-muted-foreground group-hover:text-primary group-hover:translate-x-1 transition-all" />
                    </div>
                    <CardTitle className="text-xl">{feature.title}</CardTitle>
                    <CardDescription className="text-balance leading-relaxed">{feature.description}</CardDescription>
                  </CardHeader>
                </Card>
              </Link>
            )
          })}
        </div>
      </section>

      {/* Tech Stack Section */}
      <section className="max-w-4xl mx-auto mt-20 pt-12 border-t border-border/40">
        <div className="text-center">
          <h3 className="text-xl font-semibold mb-4">Stack tecnològic</h3>
          <div className="flex flex-wrap justify-center gap-3 text-sm text-muted-foreground">
            <span className="px-3 py-1 rounded-full bg-secondary border border-border">Next.js</span>
            <span className="px-3 py-1 rounded-full bg-secondary border border-border">React</span>
            <span className="px-3 py-1 rounded-full bg-secondary border border-border">TypeScript</span>
            <span className="px-3 py-1 rounded-full bg-secondary border border-border">Prisma ORM</span>
            <span className="px-3 py-1 rounded-full bg-secondary border border-border">MySQL</span>
            <span className="px-3 py-1 rounded-full bg-secondary border border-border">Tailwind CSS</span>
          </div>
        </div>
      </section>
    </div>
  )
}
