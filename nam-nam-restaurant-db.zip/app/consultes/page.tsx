"use client"

import { useState } from "react"
import { Card, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { QueryResultTable } from "@/components/query-result-table"
import { useToast } from "@/hooks/use-toast"
import { Loader2 } from "lucide-react"

const queries = [
  {
    type: "products-with-categories",
    title: "Productes amb categories",
    description: "Llista tots els productes amb les seves categories (INNER JOIN)",
  },
  {
    type: "clients-with-orders",
    title: "Clients amb comandes",
    description: "Clients amb el total de comandes i import gastat (LEFT JOIN + GROUP BY)",
  },
  {
    type: "top-products",
    title: "Top 10 productes més venuts",
    description: "Productes més demandats amb quantitats i ingressos (agregacions)",
  },
  {
    type: "reservations-by-status",
    title: "Reserves per estat",
    description: "Resum de reserves agrupades per estat (GROUP BY)",
  },
  {
    type: "orders-by-date",
    title: "Comandes per data",
    description: "Ingressos diaris dels últims 30 dies (DATE + GROUP BY)",
  },
  {
    type: "category-revenue",
    title: "Ingressos per categoria",
    description: "Ingressos totals generats per cada categoria de productes",
  },
  {
    type: "clients-without-orders",
    title: "Clients sense comandes",
    description: "Clients registrats que encara no han fet cap comanda (LEFT JOIN + WHERE NULL)",
  },
  {
    type: "expensive-orders",
    title: "Comandes superiors a 50€",
    description: "Comandes amb import superior a 50 euros (WHERE + ORDER BY)",
  },
]

export default function ConsultesPage() {
  const [loading, setLoading] = useState(false)
  const [activeQuery, setActiveQuery] = useState<string | null>(null)
  const [results, setResults] = useState<any[]>([])
  const [currentTitle, setCurrentTitle] = useState("")
  const { toast } = useToast()

  const executeQuery = async (type: string, title: string) => {
    setLoading(true)
    setActiveQuery(type)
    setCurrentTitle(title)

    try {
      const response = await fetch(`/api/queries?type=${type}`)
      const data = await response.json()

      if (response.ok) {
        setResults(data.data || [])
      } else {
        toast({
          title: "Error",
          description: data.error || "Error al executar la consulta",
          variant: "destructive",
        })
        setResults([])
      }
    } catch (error) {
      toast({
        title: "Error",
        description: "Error de connexió amb el servidor",
        variant: "destructive",
      })
      setResults([])
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="container py-12">
      <div className="max-w-6xl mx-auto">
        <div className="mb-8">
          <h1 className="text-3xl font-bold mb-2">Consultes SQL</h1>
          <p className="text-muted-foreground text-balance">
            Executa consultes SQL predefinides per explorar les dades. Cada consulta demostra diferents tècniques:
            joins, agregacions, filtres i ordenació.
          </p>
        </div>

        {/* Query Buttons Grid */}
        <div className="grid md:grid-cols-2 gap-4 mb-8">
          {queries.map((query) => (
            <Card
              key={query.type}
              className={`cursor-pointer transition-all hover:border-primary/50 ${
                activeQuery === query.type ? "border-primary bg-primary/5" : ""
              }`}
              onClick={() => executeQuery(query.type, query.title)}
            >
              <CardHeader>
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <CardTitle className="text-lg mb-1">{query.title}</CardTitle>
                    <CardDescription className="text-balance text-sm">{query.description}</CardDescription>
                  </div>
                  {loading && activeQuery === query.type && <Loader2 className="h-5 w-5 animate-spin text-primary" />}
                </div>
              </CardHeader>
            </Card>
          ))}
        </div>

        {/* Results Table */}
        {activeQuery && !loading && <QueryResultTable data={results} title={currentTitle} />}

        {loading && (
          <Card>
            <CardHeader>
              <div className="flex items-center justify-center py-12">
                <Loader2 className="h-8 w-8 animate-spin text-primary" />
                <span className="ml-3 text-muted-foreground">Executant consulta...</span>
              </div>
            </CardHeader>
          </Card>
        )}
      </div>
    </div>
  )
}
