import { prisma } from "@/lib/prisma"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Badge } from "@/components/ui/badge"

async function getData() {
  const [categories, productes, clients, reserves, comandes] = await Promise.all([
    prisma.categoria.findMany({
      orderBy: { creat_a: "desc" },
      include: {
        _count: {
          select: { productes: true },
        },
      },
    }),
    prisma.producte.findMany({
      orderBy: { creat_a: "desc" },
      include: {
        categoria: true,
      },
    }),
    prisma.client.findMany({
      orderBy: { creat_a: "desc" },
      include: {
        _count: {
          select: { comandes: true, reserves: true },
        },
      },
    }),
    prisma.reserva.findMany({
      orderBy: { creat_a: "desc" },
      include: {
        client: true,
      },
    }),
    prisma.comanda.findMany({
      orderBy: { data_comanda: "desc" },
      include: {
        client: true,
        detalls_comanda: {
          include: {
            producte: true,
          },
        },
      },
    }),
  ])

  return { categories, productes, clients, reserves, comandes }
}

export default async function VisualitzarDadesPage() {
  const { categories, productes, clients, reserves, comandes } = await getData()

  return (
    <div className="container py-12">
      <div className="max-w-7xl mx-auto">
        <div className="mb-8">
          <h1 className="text-3xl font-bold mb-2">Visualitzar dades</h1>
          <p className="text-muted-foreground text-balance">
            Dashboard amb totes les dades emmagatzemades a la base de dades en temps real. Les taules es carreguen
            directament des de MySQL amb Prisma.
          </p>
        </div>

        <div className="space-y-8">
          {/* Categories */}
          <section>
            <Card>
              <CardHeader>
                <CardTitle>Categories</CardTitle>
                <CardDescription>
                  Totes les categories de productes del restaurant ({categories.length} total)
                </CardDescription>
              </CardHeader>
              <CardContent>
                {categories.length === 0 ? (
                  <p className="text-muted-foreground text-center py-8">No hi ha categories encara</p>
                ) : (
                  <div className="rounded-md border overflow-x-auto">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>ID</TableHead>
                          <TableHead>Nom</TableHead>
                          <TableHead>Descripció</TableHead>
                          <TableHead>Productes</TableHead>
                          <TableHead>Data creació</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {categories.map((cat) => (
                          <TableRow key={cat.id}>
                            <TableCell className="font-mono text-xs">{cat.id}</TableCell>
                            <TableCell className="font-medium">{cat.nom}</TableCell>
                            <TableCell className="text-muted-foreground">{cat.descripcio || "-"}</TableCell>
                            <TableCell>
                              <Badge variant="secondary">{cat._count.productes}</Badge>
                            </TableCell>
                            <TableCell className="text-sm">
                              {new Date(cat.creat_a).toLocaleDateString("ca-ES")}
                            </TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </div>
                )}
              </CardContent>
            </Card>
          </section>

          {/* Products */}
          <section>
            <Card>
              <CardHeader>
                <CardTitle>Productes</CardTitle>
                <CardDescription>Tots els productes del menú ({productes.length} total)</CardDescription>
              </CardHeader>
              <CardContent>
                {productes.length === 0 ? (
                  <p className="text-muted-foreground text-center py-8">No hi ha productes encara</p>
                ) : (
                  <div className="rounded-md border overflow-x-auto">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>ID</TableHead>
                          <TableHead>Nom</TableHead>
                          <TableHead>Categoria</TableHead>
                          <TableHead>Preu</TableHead>
                          <TableHead>Disponible</TableHead>
                          <TableHead>Data creació</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {productes.map((prod) => (
                          <TableRow key={prod.id}>
                            <TableCell className="font-mono text-xs">{prod.id}</TableCell>
                            <TableCell className="font-medium">{prod.nom}</TableCell>
                            <TableCell>
                              <Badge variant="outline">{prod.categoria.nom}</Badge>
                            </TableCell>
                            <TableCell className="font-semibold">{Number(prod.preu).toFixed(2)} €</TableCell>
                            <TableCell>
                              <Badge variant={prod.disponible ? "default" : "secondary"}>
                                {prod.disponible ? "Sí" : "No"}
                              </Badge>
                            </TableCell>
                            <TableCell className="text-sm">
                              {new Date(prod.creat_a).toLocaleDateString("ca-ES")}
                            </TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </div>
                )}
              </CardContent>
            </Card>
          </section>

          {/* Clients */}
          <section>
            <Card>
              <CardHeader>
                <CardTitle>Clients</CardTitle>
                <CardDescription>Tots els clients registrats ({clients.length} total)</CardDescription>
              </CardHeader>
              <CardContent>
                {clients.length === 0 ? (
                  <p className="text-muted-foreground text-center py-8">No hi ha clients encara</p>
                ) : (
                  <div className="rounded-md border overflow-x-auto">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>ID</TableHead>
                          <TableHead>Nom complet</TableHead>
                          <TableHead>Email</TableHead>
                          <TableHead>Telèfon</TableHead>
                          <TableHead>Comandes</TableHead>
                          <TableHead>Reserves</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {clients.map((client) => (
                          <TableRow key={client.id}>
                            <TableCell className="font-mono text-xs">{client.id}</TableCell>
                            <TableCell className="font-medium">
                              {client.nom} {client.cognom}
                            </TableCell>
                            <TableCell className="text-muted-foreground">{client.email}</TableCell>
                            <TableCell className="text-sm">{client.telefon || "-"}</TableCell>
                            <TableCell>
                              <Badge variant="secondary">{client._count.comandes}</Badge>
                            </TableCell>
                            <TableCell>
                              <Badge variant="secondary">{client._count.reserves}</Badge>
                            </TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </div>
                )}
              </CardContent>
            </Card>
          </section>

          {/* Reservations */}
          <section>
            <Card>
              <CardHeader>
                <CardTitle>Reserves</CardTitle>
                <CardDescription>Totes les reserves del restaurant ({reserves.length} total)</CardDescription>
              </CardHeader>
              <CardContent>
                {reserves.length === 0 ? (
                  <p className="text-muted-foreground text-center py-8">No hi ha reserves encara</p>
                ) : (
                  <div className="rounded-md border overflow-x-auto">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>ID</TableHead>
                          <TableHead>Client</TableHead>
                          <TableHead>Data reserva</TableHead>
                          <TableHead>Persones</TableHead>
                          <TableHead>Estat</TableHead>
                          <TableHead>Notes</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {reserves.map((reserva) => (
                          <TableRow key={reserva.id}>
                            <TableCell className="font-mono text-xs">{reserva.id}</TableCell>
                            <TableCell className="font-medium">
                              {reserva.client.nom} {reserva.client.cognom}
                            </TableCell>
                            <TableCell className="text-sm">
                              {new Date(reserva.data_reserva).toLocaleString("ca-ES", {
                                dateStyle: "short",
                                timeStyle: "short",
                              })}
                            </TableCell>
                            <TableCell>
                              <Badge variant="outline">{reserva.num_persones}</Badge>
                            </TableCell>
                            <TableCell>
                              <Badge
                                variant={
                                  reserva.estat === "confirmada"
                                    ? "default"
                                    : reserva.estat === "cancel·lada"
                                      ? "destructive"
                                      : "secondary"
                                }
                              >
                                {reserva.estat}
                              </Badge>
                            </TableCell>
                            <TableCell className="text-muted-foreground text-sm max-w-xs truncate">
                              {reserva.notes || "-"}
                            </TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </div>
                )}
              </CardContent>
            </Card>
          </section>

          {/* Orders */}
          <section>
            <Card>
              <CardHeader>
                <CardTitle>Comandes</CardTitle>
                <CardDescription>Totes les comandes realitzades ({comandes.length} total)</CardDescription>
              </CardHeader>
              <CardContent>
                {comandes.length === 0 ? (
                  <p className="text-muted-foreground text-center py-8">No hi ha comandes encara</p>
                ) : (
                  <div className="rounded-md border overflow-x-auto">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>ID</TableHead>
                          <TableHead>Client</TableHead>
                          <TableHead>Data</TableHead>
                          <TableHead>Articles</TableHead>
                          <TableHead>Total</TableHead>
                          <TableHead>Estat</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {comandes.map((comanda) => (
                          <TableRow key={comanda.id}>
                            <TableCell className="font-mono text-xs">{comanda.id}</TableCell>
                            <TableCell className="font-medium">
                              {comanda.client.nom} {comanda.client.cognom}
                            </TableCell>
                            <TableCell className="text-sm">
                              {new Date(comanda.data_comanda).toLocaleString("ca-ES", {
                                dateStyle: "short",
                                timeStyle: "short",
                              })}
                            </TableCell>
                            <TableCell>
                              <Badge variant="secondary">{comanda.detalls_comanda.length} articles</Badge>
                            </TableCell>
                            <TableCell className="font-semibold">{Number(comanda.total).toFixed(2)} €</TableCell>
                            <TableCell>
                              <Badge
                                variant={
                                  comanda.estat === "completada"
                                    ? "default"
                                    : comanda.estat === "cancel·lada"
                                      ? "destructive"
                                      : "secondary"
                                }
                              >
                                {comanda.estat}
                              </Badge>
                            </TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </div>
                )}
              </CardContent>
            </Card>
          </section>
        </div>
      </div>
    </div>
  )
}
