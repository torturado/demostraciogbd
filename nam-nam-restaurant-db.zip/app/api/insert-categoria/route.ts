import { NextResponse } from "next/server"
import { prisma } from "@/lib/prisma"

export async function POST(request: Request) {
  try {
    const body = await request.json()
    const { nom, descripcio } = body

    if (!nom) {
      return NextResponse.json({ error: "El nom de la categoria és obligatori" }, { status: 400 })
    }

    const categoria = await prisma.categoria.create({
      data: {
        nom,
        descripcio: descripcio || null,
      },
    })

    return NextResponse.json({
      success: true,
      data: categoria,
      message: "Categoria creada correctament",
    })
  } catch (error) {
    console.error("[v0] Error creating categoria:", error)
    return NextResponse.json({ error: "Error al crear la categoria" }, { status: 500 })
  }
}
