import { NextResponse } from "next/server"
import { prisma } from "@/lib/prisma"

export async function POST(request: Request) {
  try {
    const body = await request.json()
    const { nom, descripcio, preu, disponible, categoria_id } = body

    if (!nom || !preu || !categoria_id) {
      return NextResponse.json({ error: "Nom, preu i categoria són obligatoris" }, { status: 400 })
    }

    const producte = await prisma.producte.create({
      data: {
        nom,
        descripcio: descripcio || null,
        preu: Number.parseFloat(preu),
        disponible: disponible ?? true,
        categoria_id: Number.parseInt(categoria_id),
      },
    })

    return NextResponse.json({
      success: true,
      data: producte,
      message: "Producte creat correctament",
    })
  } catch (error) {
    console.error("[v0] Error creating producte:", error)
    return NextResponse.json({ error: "Error al crear el producte" }, { status: 500 })
  }
}
