import { NextResponse } from "next/server"
import { prisma } from "@/lib/prisma"

export async function POST(request: Request) {
  try {
    const body = await request.json()
    const { nom, cognom, email, telefon } = body

    if (!nom || !cognom || !email) {
      return NextResponse.json({ error: "Nom, cognom i email són obligatoris" }, { status: 400 })
    }

    // Check if email already exists
    const existingClient = await prisma.client.findUnique({
      where: { email },
    })

    if (existingClient) {
      return NextResponse.json({ error: "Ja existeix un client amb aquest email" }, { status: 400 })
    }

    const client = await prisma.client.create({
      data: {
        nom,
        cognom,
        email,
        telefon: telefon || null,
      },
    })

    return NextResponse.json({
      success: true,
      data: client,
      message: "Client creat correctament",
    })
  } catch (error) {
    console.error("[v0] Error creating client:", error)
    return NextResponse.json({ error: "Error al crear el client" }, { status: 500 })
  }
}
