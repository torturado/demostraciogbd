import { NextResponse } from "next/server"
import { prisma } from "@/lib/prisma"

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url)
    const type = searchParams.get("type")

    if (!type) {
      return NextResponse.json({ error: "Query type is required" }, { status: 400 })
    }

    let result: any

    switch (type) {
      case "products-with-categories":
        result = await prisma.$queryRaw`
          SELECT p.id, p.nom AS producte, p.preu, c.nom AS categoria, p.disponible
          FROM productes p
          INNER JOIN categories c ON p.categoria_id = c.id
          ORDER BY c.nom, p.nom
        `
        break

      case "clients-with-orders":
        result = await prisma.$queryRaw`
          SELECT 
            cl.id,
            CONCAT(cl.nom, ' ', cl.cognom) AS client,
            cl.email,
            COUNT(co.id) AS total_comandes,
            COALESCE(SUM(co.total), 0) AS total_gastat
          FROM clients cl
          LEFT JOIN comandes co ON cl.id = co.client_id
          GROUP BY cl.id, cl.nom, cl.cognom, cl.email
          ORDER BY total_gastat DESC
        `
        break

      case "top-products":
        result = await prisma.$queryRaw`
          SELECT 
            p.id,
            p.nom AS producte,
            COUNT(dc.id) AS vegades_demanades,
            SUM(dc.quantitat) AS quantitat_total,
            SUM(dc.subtotal) AS ingressos_totals
          FROM productes p
          INNER JOIN detalls_comanda dc ON p.id = dc.producte_id
          GROUP BY p.id, p.nom
          ORDER BY quantitat_total DESC
          LIMIT 10
        `
        break

      case "reservations-by-status":
        result = await prisma.$queryRaw`
          SELECT 
            r.estat,
            COUNT(*) AS total_reserves,
            SUM(r.num_persones) AS total_persones
          FROM reserves r
          GROUP BY r.estat
          ORDER BY total_reserves DESC
        `
        break

      case "orders-by-date":
        result = await prisma.$queryRaw`
          SELECT 
            DATE(co.data_comanda) AS data,
            COUNT(*) AS total_comandes,
            SUM(co.total) AS ingressos_dia
          FROM comandes co
          GROUP BY DATE(co.data_comanda)
          ORDER BY data DESC
          LIMIT 30
        `
        break

      case "category-revenue":
        result = await prisma.$queryRaw`
          SELECT 
            c.nom AS categoria,
            COUNT(DISTINCT p.id) AS total_productes,
            COUNT(dc.id) AS vegades_demanades,
            SUM(dc.subtotal) AS ingressos_totals
          FROM categories c
          LEFT JOIN productes p ON c.id = p.categoria_id
          LEFT JOIN detalls_comanda dc ON p.id = dc.producte_id
          GROUP BY c.id, c.nom
          ORDER BY ingressos_totals DESC
        `
        break

      case "clients-without-orders":
        result = await prisma.$queryRaw`
          SELECT 
            cl.id,
            CONCAT(cl.nom, ' ', cl.cognom) AS client,
            cl.email,
            cl.telefon
          FROM clients cl
          LEFT JOIN comandes co ON cl.id = co.client_id
          WHERE co.id IS NULL
          ORDER BY cl.nom
        `
        break

      case "expensive-orders":
        result = await prisma.$queryRaw`
          SELECT 
            co.id AS comanda_id,
            CONCAT(cl.nom, ' ', cl.cognom) AS client,
            co.data_comanda,
            co.total,
            co.estat
          FROM comandes co
          INNER JOIN clients cl ON co.client_id = cl.id
          WHERE co.total > 50
          ORDER BY co.total DESC
        `
        break

      default:
        return NextResponse.json({ error: "Invalid query type" }, { status: 400 })
    }

    return NextResponse.json({
      success: true,
      data: result,
      count: Array.isArray(result) ? result.length : 0,
    })
  } catch (error) {
    console.error("[v0] Error executing query:", error)
    return NextResponse.json({ error: "Error executing query" }, { status: 500 })
  }
}
