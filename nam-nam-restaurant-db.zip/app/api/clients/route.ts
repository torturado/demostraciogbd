import { NextResponse } from "next/server"
import { prisma } from "@/lib/prisma"

export async function GET() {
  try {
    const clients = await prisma.client.findMany({
      select: {
        id: true,
        nom: true,
        cognom: true,
        email: true,
      },
      orderBy: { nom: "asc" },
    })

    return NextResponse.json(clients)
  } catch (error) {
    console.error("[v0] Error fetching clients:", error)
    return NextResponse.json({ error: "Error al obtenir els clients" }, { status: 500 })
  }
}
