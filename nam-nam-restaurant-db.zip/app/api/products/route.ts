import { NextResponse } from "next/server"
import { prisma } from "@/lib/prisma"

export async function GET() {
  try {
    const productes = await prisma.producte.findMany({
      where: { disponible: true },
      select: {
        id: true,
        nom: true,
        preu: true,
      },
      orderBy: { nom: "asc" },
    })

    return NextResponse.json(productes)
  } catch (error) {
    console.error("[v0] Error fetching products:", error)
    return NextResponse.json({ error: "Error al obtenir els productes" }, { status: 500 })
  }
}
