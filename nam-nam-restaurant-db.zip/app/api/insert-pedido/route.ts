import { NextResponse } from "next/server"
import { prisma } from "@/lib/prisma"

export async function POST(request: Request) {
  try {
    const body = await request.json()
    const { client_id, detalls } = body

    if (!client_id || !detalls || detalls.length === 0) {
      return NextResponse.json({ error: "Client i detalls de la comanda són obligatoris" }, { status: 400 })
    }

    // Calculate total and prepare order details
    let total = 0
    const detallsData = []

    for (const detall of detalls) {
      const producte = await prisma.producte.findUnique({
        where: { id: Number.parseInt(detall.producte_id) },
      })

      if (!producte) {
        return NextResponse.json({ error: `Producte amb ID ${detall.producte_id} no trobat` }, { status: 400 })
      }

      const quantitat = Number.parseInt(detall.quantitat)
      const subtotal = Number.parseFloat(producte.preu.toString()) * quantitat
      total += subtotal

      detallsData.push({
        producte_id: producte.id,
        quantitat,
        preu_unitat: producte.preu,
        subtotal,
      })
    }

    // Create order with details in a transaction
    const comanda = await prisma.comanda.create({
      data: {
        client_id: Number.parseInt(client_id),
        total,
        estat: "pendent",
        detalls_comanda: {
          create: detallsData,
        },
      },
      include: {
        detalls_comanda: {
          include: {
            producte: true,
          },
        },
      },
    })

    return NextResponse.json({
      success: true,
      data: comanda,
      message: "Comanda creada correctament",
    })
  } catch (error) {
    console.error("[v0] Error creating comanda:", error)
    return NextResponse.json({ error: "Error al crear la comanda" }, { status: 500 })
  }
}
