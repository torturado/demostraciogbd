import { NextResponse } from "next/server"
import { prisma } from "@/lib/prisma"

export async function POST(request: Request) {
  try {
    const body = await request.json()
    const { client_id, data_reserva, num_persones, estat, notes } = body

    if (!client_id || !data_reserva || !num_persones) {
      return NextResponse.json({ error: "Client, data i número de persones són obligatoris" }, { status: 400 })
    }

    const reserva = await prisma.reserva.create({
      data: {
        client_id: Number.parseInt(client_id),
        data_reserva: new Date(data_reserva),
        num_persones: Number.parseInt(num_persones),
        estat: estat || "pendent",
        notes: notes || null,
      },
    })

    return NextResponse.json({
      success: true,
      data: reserva,
      message: "Reserva creada correctament",
    })
  } catch (error) {
    console.error("[v0] Error creating reserva:", error)
    return NextResponse.json({ error: "Error al crear la reserva" }, { status: 500 })
  }
}
