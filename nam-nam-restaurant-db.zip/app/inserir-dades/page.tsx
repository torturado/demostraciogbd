import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { CategoriaForm } from "@/components/forms/categoria-form"
import { ProducteForm } from "@/components/forms/producte-form"
import { ClientForm } from "@/components/forms/client-form"
import { Separator } from "@/components/ui/separator"

export default function InsertDataPage() {
  return (
    <div className="container py-12">
      <div className="max-w-4xl mx-auto">
        <div className="mb-8">
          <h1 className="text-3xl font-bold mb-2">Inserir dades</h1>
          <p className="text-muted-foreground text-balance">
            Utilitza els formularis per afegir noves dades a la base de dades. Cada formulari inclou validacions i
            l'opció d'autocompletar amb dades aleatòries.
          </p>
        </div>

        <div className="space-y-8">
          {/* Categories Section */}
          <section>
            <h2 className="text-2xl font-semibold mb-4">Categories</h2>
            <Card>
              <CardHeader>
                <CardTitle>Nova categoria</CardTitle>
                <CardDescription>Crea una nova categoria per organitzar els productes del restaurant.</CardDescription>
              </CardHeader>
              <CardContent>
                <CategoriaForm />
              </CardContent>
            </Card>
          </section>

          <Separator />

          {/* Products Section */}
          <section>
            <h2 className="text-2xl font-semibold mb-4">Productes</h2>
            <Card>
              <CardHeader>
                <CardTitle>Nou producte</CardTitle>
                <CardDescription>Afegeix un nou producte al menú del restaurant amb preu i categoria.</CardDescription>
              </CardHeader>
              <CardContent>
                <ProducteForm />
              </CardContent>
            </Card>
          </section>

          <Separator />

          {/* Clients Section */}
          <section>
            <h2 className="text-2xl font-semibold mb-4">Clients</h2>
            <Card>
              <CardHeader>
                <CardTitle>Nou client</CardTitle>
                <CardDescription>Registra un nou client amb les seves dades de contacte.</CardDescription>
              </CardHeader>
              <CardContent>
                <ClientForm />
              </CardContent>
            </Card>
          </section>
        </div>
      </div>
    </div>
  )
}
