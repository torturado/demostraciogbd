import { Github } from "lucide-react"
import Link from "next/link"

export function Footer() {
  return (
    <footer className="border-t border-border/40 bg-card/50 mt-auto">
      <div className="container py-8">
        <div className="flex flex-col md:flex-row items-center justify-between gap-4">
          <div className="text-sm text-muted-foreground text-center md:text-left">
            <p className="text-balance">Demo acadèmica - Base de dades Restaurant Ñam Ñam</p>
            <p className="mt-1 text-xs">Projecte educatiu per demostrar el cicle complet de dades amb MySQL i Prisma</p>
          </div>

          <div className="flex items-center gap-4">
            <Link
              href="https://github.com"
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground transition-colors"
            >
              <Github className="h-5 w-5" />
              <span>Repositori</span>
            </Link>
          </div>
        </div>

        <div className="mt-6 pt-6 border-t border-border/40 text-center text-xs text-muted-foreground">
          <p>© 2025 Ñam Ñam Restaurant Database Demo. Tots els drets reservats.</p>
        </div>
      </div>
    </footer>
  )
}
