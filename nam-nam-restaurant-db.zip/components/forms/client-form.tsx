"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { useToast } from "@/hooks/use-toast"
import { Loader2, Sparkles } from "lucide-react"

export function ClientForm() {
  const [loading, setLoading] = useState(false)
  const [nom, setNom] = useState("")
  const [cognom, setCognom] = useState("")
  const [email, setEmail] = useState("")
  const [telefon, setTelefon] = useState("")
  const { toast } = useToast()

  const handleAutoFill = () => {
    const clients = [
      { nom: "Joan", cognom: "García", email: "joan.garcia@example.com", telefon: "612345678" },
      { nom: "Maria", cognom: "Martínez", email: "maria.martinez@example.com", telefon: "623456789" },
      { nom: "Pere", cognom: "López", email: "pere.lopez@example.com", telefon: "634567890" },
      { nom: "Anna", cognom: "Fernández", email: "anna.fernandez@example.com", telefon: "645678901" },
    ]
    const random = clients[Math.floor(Math.random() * clients.length)]
    const timestamp = Date.now()
    setNom(random.nom)
    setCognom(random.cognom)
    setEmail(`${random.nom.toLowerCase()}.${timestamp}@example.com`)
    setTelefon(random.telefon)
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)

    try {
      const response = await fetch("/api/insert-client", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ nom, cognom, email, telefon }),
      })

      const data = await response.json()

      if (response.ok) {
        toast({ title: "Èxit", description: data.message })
        setNom("")
        setCognom("")
        setEmail("")
        setTelefon("")
      } else {
        toast({ title: "Error", description: data.error, variant: "destructive" })
      }
    } catch (error) {
      toast({ title: "Error", description: "Error de connexió", variant: "destructive" })
    } finally {
      setLoading(false)
    }
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div className="grid grid-cols-2 gap-4">
        <div className="space-y-2">
          <Label htmlFor="nom-client">Nom *</Label>
          <Input
            id="nom-client"
            value={nom}
            onChange={(e) => setNom(e.target.value)}
            placeholder="Joan"
            required
            disabled={loading}
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="cognom">Cognom *</Label>
          <Input
            id="cognom"
            value={cognom}
            onChange={(e) => setCognom(e.target.value)}
            placeholder="García"
            required
            disabled={loading}
          />
        </div>
      </div>

      <div className="space-y-2">
        <Label htmlFor="email">Email *</Label>
        <Input
          id="email"
          type="email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          placeholder="joan.garcia@example.com"
          required
          disabled={loading}
        />
      </div>

      <div className="space-y-2">
        <Label htmlFor="telefon">Telèfon</Label>
        <Input
          id="telefon"
          type="tel"
          value={telefon}
          onChange={(e) => setTelefon(e.target.value)}
          placeholder="612345678"
          disabled={loading}
        />
      </div>

      <div className="flex gap-2">
        <Button
          type="button"
          variant="outline"
          onClick={handleAutoFill}
          disabled={loading}
          className="gap-2 bg-transparent"
        >
          <Sparkles className="h-4 w-4" />
          Autocompletar
        </Button>
        <Button type="submit" disabled={loading} className="gap-2">
          {loading && <Loader2 className="h-4 w-4 animate-spin" />}
          Crear client
        </Button>
      </div>
    </form>
  )
}
