"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { useToast } from "@/hooks/use-toast"
import { Loader2, Sparkles } from "lucide-react"

export function CategoriaForm() {
  const [loading, setLoading] = useState(false)
  const [nom, setNom] = useState("")
  const [descripcio, setDescripcio] = useState("")
  const { toast } = useToast()

  const handleAutoFill = () => {
    const categories = [
      { nom: "Entrants", descripcio: "Plats per començar el menjar" },
      { nom: "Plats principals", descripcio: "Plats forts del restaurant" },
      { nom: "Postres", descripcio: "Dolços i postres casolanes" },
      { nom: "Begudes", descripcio: "Refrescos, vins i altres begudes" },
      { nom: "Amanides", descripcio: "Amanides fresques i saludables" },
    ]
    const random = categories[Math.floor(Math.random() * categories.length)]
    setNom(random.nom)
    setDescripcio(random.descripcio)
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)

    try {
      const response = await fetch("/api/insert-categoria", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ nom, descripcio }),
      })

      const data = await response.json()

      if (response.ok) {
        toast({
          title: "Èxit",
          description: data.message,
        })
        setNom("")
        setDescripcio("")
      } else {
        toast({
          title: "Error",
          description: data.error,
          variant: "destructive",
        })
      }
    } catch (error) {
      toast({
        title: "Error",
        description: "Error de connexió amb el servidor",
        variant: "destructive",
      })
    } finally {
      setLoading(false)
    }
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div className="space-y-2">
        <Label htmlFor="nom">Nom de la categoria *</Label>
        <Input
          id="nom"
          value={nom}
          onChange={(e) => setNom(e.target.value)}
          placeholder="Ex: Entrants"
          required
          disabled={loading}
        />
      </div>

      <div className="space-y-2">
        <Label htmlFor="descripcio">Descripció</Label>
        <Textarea
          id="descripcio"
          value={descripcio}
          onChange={(e) => setDescripcio(e.target.value)}
          placeholder="Descripció opcional de la categoria"
          disabled={loading}
          rows={3}
        />
      </div>

      <div className="flex gap-2">
        <Button
          type="button"
          variant="outline"
          onClick={handleAutoFill}
          disabled={loading}
          className="gap-2 bg-transparent"
        >
          <Sparkles className="h-4 w-4" />
          Autocompletar
        </Button>
        <Button type="submit" disabled={loading} className="gap-2">
          {loading && <Loader2 className="h-4 w-4 animate-spin" />}
          Crear categoria
        </Button>
      </div>
    </form>
  )
}
