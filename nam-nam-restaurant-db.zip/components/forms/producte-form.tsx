"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Checkbox } from "@/components/ui/checkbox"
import { useToast } from "@/hooks/use-toast"
import { Loader2, Sparkles } from "lucide-react"

export function ProducteForm() {
  const [loading, setLoading] = useState(false)
  const [categories, setCategories] = useState<any[]>([])
  const [nom, setNom] = useState("")
  const [descripcio, setDescripcio] = useState("")
  const [preu, setPreu] = useState("")
  const [disponible, setDisponible] = useState(true)
  const [categoriaId, setCategoriaId] = useState("")
  const { toast } = useToast()

  useEffect(() => {
    fetch("/api/categories")
      .then((res) => res.json())
      .then((data) => setCategories(data))
      .catch(() => toast({ title: "Error", description: "Error al carregar categories", variant: "destructive" }))
  }, [])

  const handleAutoFill = () => {
    const productes = [
      { nom: "Paella valenciana", descripcio: "Paella tradicional amb marisc", preu: "15.50" },
      { nom: "Entrecot a la brasa", descripcio: "Entrecot de vedella amb patates", preu: "18.00" },
      { nom: "Tiramisú", descripcio: "Postres italiana amb cafè", preu: "5.50" },
      { nom: "Amanida Cèsar", descripcio: "Amanida fresca amb pollastre", preu: "8.50" },
    ]
    const random = productes[Math.floor(Math.random() * productes.length)]
    setNom(random.nom)
    setDescripcio(random.descripcio)
    setPreu(random.preu)
    setDisponible(true)
    if (categories.length > 0) {
      setCategoriaId(categories[0].id.toString())
    }
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)

    try {
      const response = await fetch("/api/insert-product", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ nom, descripcio, preu, disponible, categoria_id: categoriaId }),
      })

      const data = await response.json()

      if (response.ok) {
        toast({ title: "Èxit", description: data.message })
        setNom("")
        setDescripcio("")
        setPreu("")
        setDisponible(true)
        setCategoriaId("")
      } else {
        toast({ title: "Error", description: data.error, variant: "destructive" })
      }
    } catch (error) {
      toast({ title: "Error", description: "Error de connexió", variant: "destructive" })
    } finally {
      setLoading(false)
    }
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div className="space-y-2">
        <Label htmlFor="nom-producte">Nom del producte *</Label>
        <Input
          id="nom-producte"
          value={nom}
          onChange={(e) => setNom(e.target.value)}
          placeholder="Ex: Paella valenciana"
          required
          disabled={loading}
        />
      </div>

      <div className="space-y-2">
        <Label htmlFor="descripcio-producte">Descripció</Label>
        <Textarea
          id="descripcio-producte"
          value={descripcio}
          onChange={(e) => setDescripcio(e.target.value)}
          placeholder="Descripció del producte"
          disabled={loading}
          rows={2}
        />
      </div>

      <div className="grid grid-cols-2 gap-4">
        <div className="space-y-2">
          <Label htmlFor="preu">Preu (€) *</Label>
          <Input
            id="preu"
            type="number"
            step="0.01"
            value={preu}
            onChange={(e) => setPreu(e.target.value)}
            placeholder="0.00"
            required
            disabled={loading}
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="categoria">Categoria *</Label>
          <Select value={categoriaId} onValueChange={setCategoriaId} disabled={loading} required>
            <SelectTrigger id="categoria">
              <SelectValue placeholder="Selecciona categoria" />
            </SelectTrigger>
            <SelectContent>
              {categories.map((cat) => (
                <SelectItem key={cat.id} value={cat.id.toString()}>
                  {cat.nom}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </div>

      <div className="flex items-center space-x-2">
        <Checkbox
          id="disponible"
          checked={disponible}
          onCheckedChange={(checked) => setDisponible(checked as boolean)}
          disabled={loading}
        />
        <Label htmlFor="disponible" className="cursor-pointer">
          Producte disponible
        </Label>
      </div>

      <div className="flex gap-2">
        <Button
          type="button"
          variant="outline"
          onClick={handleAutoFill}
          disabled={loading}
          className="gap-2 bg-transparent"
        >
          <Sparkles className="h-4 w-4" />
          Autocompletar
        </Button>
        <Button type="submit" disabled={loading} className="gap-2">
          {loading && <Loader2 className="h-4 w-4 animate-spin" />}
          Crear producte
        </Button>
      </div>
    </form>
  )
}
