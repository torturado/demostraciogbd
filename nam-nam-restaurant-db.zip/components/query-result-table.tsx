import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"

interface QueryResultTableProps {
  data: any[]
  title: string
  description?: string
}

export function QueryResultTable({ data, title, description }: QueryResultTableProps) {
  if (!data || data.length === 0) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>{title}</CardTitle>
          {description && <CardDescription>{description}</CardDescription>}
        </CardHeader>
        <CardContent>
          <p className="text-muted-foreground text-center py-8">No s'han trobat resultats</p>
        </CardContent>
      </Card>
    )
  }

  const columns = Object.keys(data[0])

  const formatValue = (value: any, key: string) => {
    if (value === null || value === undefined) return "-"

    // Format boolean values
    if (typeof value === "boolean") {
      return (
        <Badge variant={value ? "default" : "secondary"} className="text-xs">
          {value ? "Sí" : "No"}
        </Badge>
      )
    }

    // Format numbers with decimals (prices)
    if (typeof value === "number" && key.toLowerCase().includes("preu")) {
      return `${value.toFixed(2)} €`
    }

    if (typeof value === "number" && (key.toLowerCase().includes("total") || key.toLowerCase().includes("ingressos"))) {
      return `${value.toFixed(2)} €`
    }

    // Format dates
    if (
      value instanceof Date ||
      (typeof value === "string" && !Number.isNaN(Date.parse(value)) && value.includes("-"))
    ) {
      try {
        const date = new Date(value)
        return date.toLocaleDateString("ca-ES", {
          year: "numeric",
          month: "2-digit",
          day: "2-digit",
        })
      } catch {
        return value
      }
    }

    // Format BigInt
    if (typeof value === "bigint") {
      return value.toString()
    }

    return value.toString()
  }

  const formatColumnName = (col: string) => {
    return col
      .split("_")
      .map((word) => word.charAt(0).toUpperCase() + word.slice(1))
      .join(" ")
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>{title}</CardTitle>
        {description && <CardDescription>{description}</CardDescription>}
        <div className="text-sm text-muted-foreground">
          <Badge variant="outline">{data.length} resultats</Badge>
        </div>
      </CardHeader>
      <CardContent>
        <div className="rounded-md border overflow-x-auto">
          <Table>
            <TableHeader>
              <TableRow>
                {columns.map((col) => (
                  <TableHead key={col} className="font-semibold">
                    {formatColumnName(col)}
                  </TableHead>
                ))}
              </TableRow>
            </TableHeader>
            <TableBody>
              {data.map((row, idx) => (
                <TableRow key={idx}>
                  {columns.map((col) => (
                    <TableCell key={col}>{formatValue(row[col], col)}</TableCell>
                  ))}
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
      </CardContent>
    </Card>
  )
}
